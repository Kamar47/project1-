package server;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import common.Command;
import common.Message;
import common.Order;
import ocsf.server.AbstractServer;
import ocsf.server.ConnectionToClient;

/**
 * GoNatureServer extends AbstractServer (OCSF).
 * Uses Command enum for type-safe message handling.
 */
public class GoNatureServer extends AbstractServer {

    private MysqlConnection dbConnection;
    private ServerUIController uiController;
    private static final int NO_CLIENTS_TIMEOUT_MINUTES = 2;

    private ScheduledExecutorService noClientsScheduler;
    private ScheduledFuture<?> noClientsTask;
    private int connectedClientsCount = 0;
    private boolean serverIsStopping = false;

    public GoNatureServer(int port) {
        super(port);
        dbConnection = new MysqlConnection();
    }

    public void setUiController(ServerUIController controller) {
        this.uiController = controller;
    }

    public void connectToDatabase(String dbUrl, String dbUser, String dbPass) throws Exception {
        dbConnection.connectToDatabase(dbUrl, dbUser, dbPass);
    }

    @Override
    protected void handleMessageFromClient(Object msg, ConnectionToClient client) {
        if (!(msg instanceof Message)) {
            logToUI("Received unknown message type from " + client);
            return;
        }

        Message message = (Message) msg;

        // Handle disconnect message
        if (message.getCommand() == Command.CLIENT_DISCONNECT) {
            client.setInfo("CleanDisconnect", true);
            processDisconnection(client, "graceful");
            try { client.close(); } catch (Exception e) {}
            return;
        }

        // Handle hostname identification
        if (message.getCommand() == Command.CLIENT_CONNECT) {
            String clientHostName = (String) message.getData();
            String ip = (String) client.getInfo("IP");
            client.setInfo("HostName", clientHostName);
            logToUI("Client Connected - IP: " + ip + " | Host: " + clientHostName);
            if (uiController != null) {
                uiController.removeClient(ip);
                uiController.addClient(ip, clientHostName, "Connected");
            }
            return;
        }

        logToUI("Received: " + message.getCommand() + " from " + client.getInfo("IP"));

        try {
            switch (message.getCommand()) {

                case GET_ORDER:
                    int orderNum = (int) message.getData();
                    Order order = dbConnection.getOrder(orderNum);
                    if (order != null) {
                        client.sendToClient(new Message(Command.ORDER_FOUND, order));
                        logToUI("Sent order #" + orderNum + " to client.");
                    } else {
                        client.sendToClient(new Message(Command.ORDER_NOT_FOUND, orderNum));
                        logToUI("Order #" + orderNum + " not found.");
                    }
                    break;

                case GET_ALL_ORDERS:
                    List<Order> orders = dbConnection.getAllOrders();
                    client.sendToClient(new Message(Command.ALL_ORDERS, orders));
                    logToUI("Sent " + orders.size() + " orders to client.");
                    break;

                case UPDATE_ORDER:
                    Order updateData = (Order) message.getData();
                    boolean success = dbConnection.updateOrder(
                        updateData.getOrderNumber(),
                        updateData.getOrderDate(),
                        updateData.getNumberOfVisitors()
                    );
                    if (success) {
                        client.sendToClient(new Message(Command.UPDATE_SUCCESS, updateData.getOrderNumber()));
                        logToUI("Updated order #" + updateData.getOrderNumber());
                    } else {
                        client.sendToClient(new Message(Command.UPDATE_FAIL, updateData.getOrderNumber()));
                        logToUI("Failed to update order #" + updateData.getOrderNumber());
                    }
                    break;

                default:
                    client.sendToClient(new Message(Command.ERROR, "Unknown command."));
                    logToUI("Unknown command: " + message.getCommand());
                    break;
            }
        } catch (Exception e) {
            logToUI("Error handling message: " + e.getMessage());
            try {
                client.sendToClient(new Message(Command.ERROR, e.getMessage()));
            } catch (IOException ex) {
                logToUI("Failed to send error response to client.");
            }
        }
    }

    @Override
    protected synchronized void clientConnected(ConnectionToClient client) {
        connectedClientsCount++;
        cancelNoClientsTimeout();

        if (connectedClientsCount == 1) {
            logToUI("First client connected. Server will continue running normally.");
        }

        String ip = client.getInetAddress().getHostAddress();
        client.setInfo("IP", ip);

        if (uiController != null) {
            uiController.addClient(ip, "Identifying...", "Connected");
        }
    }

    @Override
    synchronized protected void clientDisconnected(ConnectionToClient client) {
        if (client.getInfo("CleanDisconnect") != null) {
            processDisconnection(client, "graceful");
        } else {
            processDisconnection(client, "unexpected");
        }
    }

    @Override
    synchronized protected void clientException(ConnectionToClient client, Throwable exception) {
        if (client.getInfo("CleanDisconnect") != null) {
            processDisconnection(client, "graceful");
        } else {
            processDisconnection(client, "unexpected");
        }
    }

    private synchronized void processDisconnection(ConnectionToClient client, String reason) {
        if (client.getInfo("Disconnected") == null) {
            client.setInfo("Disconnected", true);

            if (connectedClientsCount > 0) {
                connectedClientsCount--;
            }

            String ip = client.getInfo("IP") != null
                    ? (String) client.getInfo("IP") : "unknown";
            String hostName = client.getInfo("HostName") != null
                    ? (String) client.getInfo("HostName") : "unknown";

            client.setInfo("DisconnectReason", reason);
            logToUI("Client Disconnected - IP: " + ip + " | Host: " + hostName);

            if (uiController != null) {
                uiController.removeClient(ip);
            }

            if (connectedClientsCount == 0 && !serverIsStopping) {
                logToUI("Last client disconnected. If no client connects within "
                        + NO_CLIENTS_TIMEOUT_MINUTES + " minutes, the server will stop automatically.");
                startNoClientsTimeout();
            }
        }
    }

    @Override
    protected synchronized void serverStarted() {
        serverIsStopping = false;
        connectedClientsCount = 0;
        logToUI("Server started on port " + getPort());
        logToUI("If no client connects within " + NO_CLIENTS_TIMEOUT_MINUTES
                + " minutes, the server will stop automatically.");
        startNoClientsTimeout();
    }

    public synchronized void stopServerManually() throws IOException {
        serverIsStopping = true;
        cancelNoClientsTimeout();
        close();
    }

    @Override
    protected void serverStopped() {
        logToUI("Server stopped listening.");
    }

    @Override
    protected synchronized void serverClosed() {
        cancelNoClientsTimeout();
        if (noClientsScheduler != null) {
            noClientsScheduler.shutdownNow();
            noClientsScheduler = null;
        }
        logToUI("Server closed.");
        dbConnection.closeConnection();
    }

    private synchronized void startNoClientsTimeout() {
        if (noClientsScheduler == null || noClientsScheduler.isShutdown()) {
            noClientsScheduler = Executors.newSingleThreadScheduledExecutor();
        }
        if (noClientsTask != null && !noClientsTask.isDone()) {
            noClientsTask.cancel(false);
        }
        noClientsTask = noClientsScheduler.schedule(() -> {
            synchronized (GoNatureServer.this) {
                if (connectedClientsCount == 0) {
                    logToUI("No clients connected for " + NO_CLIENTS_TIMEOUT_MINUTES
                            + " minutes. Server will stop automatically.");
                    try { close(); } catch (Exception e) {
                        logToUI("Error while stopping server automatically: " + e.getMessage());
                    }
                    if (uiController != null) {
                        uiController.onServerStoppedByTimeout();
                    }
                }
            }
        }, NO_CLIENTS_TIMEOUT_MINUTES, TimeUnit.MINUTES);
    }

    private synchronized void cancelNoClientsTimeout() {
        if (noClientsTask != null && !noClientsTask.isDone()) {
            noClientsTask.cancel(false);
        }
    }

    private void logToUI(String message) {
        System.out.println("[Server] " + message);
        if (uiController != null) {
            uiController.appendLog(message);
        }
    }
}
