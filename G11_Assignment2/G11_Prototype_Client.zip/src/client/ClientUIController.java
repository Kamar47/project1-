package client;

/**
 * Interface for Client UI updates.
 * Allows the client logic to update the GUI without direct dependency.
 */
public interface ClientUIController {
    void appendLog(String message);
    void displayOrder(Object orderData);
    void displayAllOrders(Object ordersData);
    void onUpdateSuccess(int orderNumber);
    void onServerDisconnected(String reason);
}
