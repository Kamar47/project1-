package gui;

import client.*;
import common.*;
import common.worker.GeneralParkWorker;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.*;
import javafx.scene.control.*;
import java.net.URL;
import java.util.*;

public class ParkManagerParametersController implements Initializable, ClientMessageHandler {
    @FXML private Label parkNameLabel, statusLabel;
    @FXML private Label currentMaxVisitors, currentGap, currentStayTime;
    @FXML private TextField newMaxVisitors, newGap, newStayTime;
    @FXML private TableView<ArrayList<String>> requestsTable;
    @FXML private TableColumn<ArrayList<String>, String> colParam, colOld, colNew, colStatus, colDate;

    private Park currentPark;
    private String currentAction;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colParam.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().get(0)));
        colOld.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().get(1)));
        colNew.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().get(2)));
        colStatus.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().get(3)));
        colDate.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().get(4)));

        loadParkData();
    }

    private void loadParkData() {
        GeneralParkWorker w = WorkerLoginController.getLoggedInWorker();
        currentAction = "LOAD_PARK";
        ClientUI.client.setHandler(this);
        ClientUI.client.sendMessage(new ClientServerMessage(Command.GET_PARK_DETAILS, w.getParkId()));
    }

    @FXML
    private void handleSubmit() {
        if (currentPark == null) { statusLabel.setText("Park data not loaded yet."); return; }

        String maxV = newMaxVisitors.getText().trim();
        String gap = newGap.getText().trim();
        String stay = newStayTime.getText().trim();

        if (maxV.isEmpty() && gap.isEmpty() && stay.isEmpty()) {
            statusLabel.setText("Enter at least one new value.");
            statusLabel.setStyle("-fx-text-fill: #f87171;");
            return;
        }

        GeneralParkWorker w = WorkerLoginController.getLoggedInWorker();
        int sent = 0;

        try {
            if (!maxV.isEmpty()) {
                int val = Integer.parseInt(maxV);
                if (val <= 0) { statusLabel.setText("Max visitors must be positive."); statusLabel.setStyle("-fx-text-fill: #f87171;"); return; }
                sendRequest(w, "max_visitors", currentPark.getMaxVisitors(), val); sent++;
            }
            if (!gap.isEmpty()) {
                int val = Integer.parseInt(gap);
                if (val < 0) { statusLabel.setText("Gap cannot be negative."); statusLabel.setStyle("-fx-text-fill: #f87171;"); return; }
                sendRequest(w, "gap_for_walkins", currentPark.getGapForWalkins(), val); sent++;
            }
            if (!stay.isEmpty()) {
                double val = Double.parseDouble(stay);
                if (val <= 0) { statusLabel.setText("Stay time must be positive."); statusLabel.setStyle("-fx-text-fill: #f87171;"); return; }
                sendRequest(w, "estimated_visit_duration", currentPark.getEstimatedVisitDuration(), val); sent++;
            }
        } catch (NumberFormatException e) {
            statusLabel.setText("Values must be numbers.");
            statusLabel.setStyle("-fx-text-fill: #f87171;");
            return;
        }

        statusLabel.setText(sent + " change request(s) sent for approval.");
        statusLabel.setStyle("-fx-text-fill: #34d399;");
        newMaxVisitors.clear(); newGap.clear(); newStayTime.clear();

        // Reload requests after short delay
        new Thread(() -> {
            try { Thread.sleep(500); } catch (InterruptedException e) {}
            Platform.runLater(this::loadRequests);
        }).start();
    }

    private void sendRequest(GeneralParkWorker w, String param, double oldVal, double newVal) {
        ArrayList<Object> params = new ArrayList<>();
        params.add(w.getParkId());
        params.add(param);
        params.add(oldVal);
        params.add(newVal);
        params.add(w.getEmployeeId());
        currentAction = "SUBMIT";
        ClientUI.client.setHandler(this);
        ClientUI.client.sendMessage(new ClientServerMessage(Command.REQUEST_PARAMETER_CHANGE, params));
    }

    private void loadRequests() {
        GeneralParkWorker w = WorkerLoginController.getLoggedInWorker();
        currentAction = "LOAD_REQUESTS";
        ClientUI.client.setHandler(this);
        ClientUI.client.sendMessage(new ClientServerMessage(Command.GET_MY_PARAMETER_REQUESTS, w.getParkId()));
    }

    @Override
    @SuppressWarnings("unchecked")
    public void handleMessage(ClientServerMessage msg) {
        Platform.runLater(() -> {
            switch (currentAction) {
                case "LOAD_PARK":
                    if (msg.getData() instanceof Park) {
                        currentPark = (Park) msg.getData();
                        parkNameLabel.setText(currentPark.getParkName());
                        currentMaxVisitors.setText(String.valueOf(currentPark.getMaxVisitors()));
                        currentGap.setText(String.valueOf(currentPark.getGapForWalkins()));
                        currentStayTime.setText(String.valueOf(currentPark.getEstimatedVisitDuration()));
                        loadRequests();
                    }
                    break;
                case "LOAD_REQUESTS":
                    if (msg.getData() instanceof ArrayList) {
                        ArrayList<ArrayList<String>> requests = (ArrayList<ArrayList<String>>) msg.getData();
                        requestsTable.setItems(FXCollections.observableArrayList(requests));
                    }
                    break;
                case "SUBMIT":
                    // Status already shown
                    break;
            }
        });
    }

    @Override
    public void onDisconnected(String r) { Platform.runLater(() -> statusLabel.setText(r)); }
}