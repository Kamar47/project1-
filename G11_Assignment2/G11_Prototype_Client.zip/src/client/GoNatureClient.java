package client;

import java.net.InetAddress;
import common.Command;
import common.Message;
import ocsf.client.AbstractClient;

/**
 * GoNatureClient extends AbstractClient (OCSF).
 * Uses Command enum for type-safe message handling.
 */
public class GoNatureClient extends AbstractClient {

    private ClientUIController uiController;

    public GoNatureClient(String host, int port) {
        super(host, port);
    }

    public void setUiController(ClientUIController controller) {
        this.uiController = controller;
    }

    @Override
    protected void handleMessageFromServer(Object msg) {
        if (!(msg instanceof Message)) {
            logToUI("Received unknown message type from server.");
            return;
        }

        Message message = (Message) msg;

        switch (message.getCommand()) {
            case ORDER_FOUND:
                if (uiController != null) uiController.displayOrder(message.getData());
                break;
            case ORDER_NOT_FOUND:
                logToUI("Order #" + message.getData() + " was not found in the database.");
                break;
            case ALL_ORDERS:
                if (uiController != null) uiController.displayAllOrders(message.getData());
                break;
            case UPDATE_SUCCESS:
                logToUI("Order #" + message.getData() + " updated successfully!");
                if (uiController != null) uiController.onUpdateSuccess((int) message.getData());
                break;
            case UPDATE_FAIL:
                logToUI("Failed to update order #" + message.getData());
                break;
            case ERROR:
                logToUI("Server error: " + message.getData());
                break;
            default:
                logToUI("Unknown response: " + message.getCommand());
                break;
        }
    }

    @Override
    protected void connectionEstablished() {
        logToUI("Connected to server at " + getHost() + ":" + getPort());
        try {
            String hostName = InetAddress.getLocalHost().getHostName();
            String myIp = InetAddress.getLocalHost().getHostAddress();
            logToUI("My IP: " + myIp + " | My Host: " + hostName);
            logToUI("Please click 'Get All Orders' to load and display the orders.");
            sendToServer(new Message(Command.CLIENT_CONNECT, hostName));
        } catch (Exception e) {
            logToUI("Warning: Could not send hostname to server.");
        }
    }

    @Override
    protected void connectionClosed() {
        if (uiController != null) {
            uiController.onServerDisconnected("Server connection closed.");
        }
    }

    @Override
    protected void connectionException(Exception exception) {
        logToUI("Disconnected from server.");
        if (uiController != null) {
            uiController.onServerDisconnected("Disconnected from server.");
        }
    }

    public void disconnectGracefully() {
        try {
            if (isConnected()) {
                sendToServer(new Message(Command.CLIENT_DISCONNECT, null));
                closeConnection();
            }
        } catch (Exception e) {
            logToUI("Warning: Could not disconnect cleanly: " + e.getMessage());
        }
    }

    public void sendRequest(Message message) {
        try {
            sendToServer(message);
        } catch (Exception e) {
            logToUI("Failed to send message: " + e.getMessage());
        }
    }

    private void logToUI(String message) {
        System.out.println("[Client] " + message);
        if (uiController != null) uiController.appendLog(message);
    }
}
