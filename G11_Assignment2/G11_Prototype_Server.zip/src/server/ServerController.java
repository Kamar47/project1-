package server;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

/**
 * ServerController - Handles all logic for the Server FXML screen.
 * Connected to ServerView.fxml via fx:controller.
 */
public class ServerController implements Initializable, ServerUIController {

    private GoNatureServer server;
    private ObservableList<ClientInfo> clientData;

    // === FXML Components (linked to ServerView.fxml) ===

    @FXML private TextField portField;
    @FXML private TextField dbUrlField;
    @FXML private TextField dbUserField;
    @FXML private PasswordField dbPassField;

    @FXML private Button startButton;
    @FXML private Button stopButton;

    @FXML private TableView<ClientInfo> clientTable;
    @FXML private TableColumn<ClientInfo, String> colIp;
    @FXML private TableColumn<ClientInfo, String> colHost;
    @FXML private TableColumn<ClientInfo, String> colStatus;

    @FXML private TextArea logArea;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Set up client table columns
        colIp.setCellValueFactory(data -> data.getValue().ipProperty());
        colHost.setCellValueFactory(data -> data.getValue().hostNameProperty());
        colStatus.setCellValueFactory(data -> data.getValue().statusProperty());

        clientData = FXCollections.observableArrayList();
        clientTable.setItems(clientData);

        appendLog("Server UI loaded. Configure and click 'Start Server'.");
    }

    // ==================== FXML EVENT HANDLERS ====================

    @FXML
    private void handleStart() {
        String portStr = portField.getText().trim();
        String dbUrl = dbUrlField.getText().trim();
        String dbUser = dbUserField.getText().trim();
        String dbPass = dbPassField.getText();

        boolean hasError = false;
        int port = -1;

        if (portStr.isEmpty()) {
            appendLog("ERROR: Please enter a port number.");
            hasError = true;
        } else {
            try {
                port = Integer.parseInt(portStr);
                if (port <= 0 || port > 65535) {
                    appendLog("ERROR: Port must be between 1 and 65535.");
                    hasError = true;
                }
            } catch (NumberFormatException e) {
                appendLog("ERROR: Port must be a number (e.g., 5555).");
                hasError = true;
            }
        }

        if (dbUrl.isEmpty()) { appendLog("ERROR: Please enter a database URL."); hasError = true; }
        if (dbUser.isEmpty()) { appendLog("ERROR: Please enter a database username."); hasError = true; }
        if (dbPass.isEmpty()) { appendLog("ERROR: Please enter a database password."); hasError = true; }

        if (hasError) return;

        try {
            server = new GoNatureServer(port);
            server.setUiController(this);

            server.connectToDatabase(dbUrl, dbUser, dbPass);
            appendLog("Connected to database successfully.");
            server.listen();

            startButton.setDisable(true);
            stopButton.setDisable(false);
            portField.setDisable(true);
            dbUrlField.setDisable(true);
            dbUserField.setDisable(true);
            dbPassField.setDisable(true);

        } catch (Exception e) {
            appendLog("ERROR: " + e.getMessage());
        }
    }

    @FXML
    private void handleStop() {
        if (server != null) {
            try {
                server.stopServerManually();
            } catch (Exception e) {
                appendLog("Error stopping server: " + e.getMessage());
            }
        }
        resetUIAfterStop();
    }

    private void resetUIAfterStop() {
        Platform.runLater(() -> {
            clientData.clear();
            startButton.setDisable(false);
            stopButton.setDisable(true);
            portField.setDisable(false);
            dbUrlField.setDisable(false);
            dbUserField.setDisable(false);
            dbPassField.setDisable(false);
        });
    }

    /**
     * Called when the window is closing.
     */
    public void shutdown() {
        handleStop();
    }

    // ==================== ServerUIController ====================

    @Override
    public void appendLog(String message) {
        Platform.runLater(() -> logArea.appendText(message + "\n"));
    }

    @Override
    public void addClient(String ip, String hostName, String status) {
        Platform.runLater(() -> clientData.add(new ClientInfo(ip, hostName, status)));
    }

    @Override
    public void removeClient(String ip) {
        Platform.runLater(() -> clientData.removeIf(c -> c.getIp().equals(ip)));
    }

    @Override
    public void onServerStoppedByTimeout() {
        Platform.runLater(() -> {
            resetUIAfterStop();
            appendLog("Server stopped automatically because no client connected within 2 minutes.");
        });
    }
}
