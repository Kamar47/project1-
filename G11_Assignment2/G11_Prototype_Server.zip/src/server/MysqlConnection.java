package server;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import common.Order;

/**
 * Handles all database operations for the GoNature prototype.
 * Maintains a single persistent connection (Approach 1 - open on start, close on shutdown).
 * Only the server accesses the DB - client never sees this class.
 */
public class MysqlConnection {

    private Connection dbConnection;

    /**
     * Opens a single connection to MySQL. Called once when server starts.
     */
    public void connectToDatabase(String url, String user, String pass) throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            dbConnection = DriverManager.getConnection(url, user, pass);
            System.out.println("Database connected successfully.");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found.", e);
        }
    }

    public Order getOrder(int orderNumber) throws SQLException {
        String query = "SELECT * FROM `Order` WHERE order_number = ?";
        PreparedStatement stmt = dbConnection.prepareStatement(query);
        stmt.setInt(1, orderNumber);
        ResultSet rs = stmt.executeQuery();
        Order order = null;
        if (rs.next()) {
            order = extractOrderFromResultSet(rs);
        }
        rs.close();
        stmt.close();
        return order;
    }

    public List<Order> getAllOrders() throws SQLException {
        List<Order> orders = new ArrayList<>();
        String query = "SELECT * FROM `Order` ORDER BY order_number";
        Statement stmt = dbConnection.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        while (rs.next()) {
            orders.add(extractOrderFromResultSet(rs));
        }
        rs.close();
        stmt.close();
        return orders;
    }

    public boolean updateOrder(int orderNumber, String newDate, int newVisitors) throws SQLException {
        String query = "UPDATE `Order` SET order_date = ?, number_of_visitors = ? WHERE order_number = ?";
        PreparedStatement stmt = dbConnection.prepareStatement(query);
        stmt.setDate(1, Date.valueOf(newDate));
        stmt.setInt(2, newVisitors);
        stmt.setInt(3, orderNumber);
        int rowsAffected = stmt.executeUpdate();
        stmt.close();
        return rowsAffected > 0;
    }

    private Order extractOrderFromResultSet(ResultSet rs) throws SQLException {
        return new Order(
            rs.getInt("order_number"),
            rs.getDate("order_date") != null ? rs.getDate("order_date").toString() : "",
            rs.getInt("number_of_visitors"),
            rs.getInt("confirmation_code"),
            rs.getInt("subscriber_id"),
            rs.getDate("date_of_placing_order") != null ? rs.getDate("date_of_placing_order").toString() : ""
        );
    }

    /** Closes the single DB connection. Called once when server shuts down. */
    public void closeConnection() {
        if (dbConnection != null) {
            try {
                dbConnection.close();
                System.out.println("Database connection closed.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean isConnected() {
        try {
            return dbConnection != null && !dbConnection.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }
}
