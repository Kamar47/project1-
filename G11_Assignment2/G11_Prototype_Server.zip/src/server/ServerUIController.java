package server;

/**
 * Interface for Server UI updates.
 */
public interface ServerUIController {
    void appendLog(String message);
    void addClient(String ip, String hostName, String status);
    void removeClient(String ip);
    void onServerStoppedByTimeout();
}
