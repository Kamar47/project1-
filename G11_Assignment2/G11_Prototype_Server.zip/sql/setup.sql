-- GoNature Prototype - Database Setup
-- Run this script in MySQL Workbench before starting the prototype

CREATE DATABASE IF NOT EXISTS gonature;
USE gonature;

DROP TABLE IF EXISTS `Order`;

CREATE TABLE `Order` (
    order_number INT PRIMARY KEY,
    order_date DATE,
    number_of_visitors INT,
    confirmation_code INT,
    subscriber_id INT,
    date_of_placing_order DATE
);

INSERT INTO `Order` VALUES 
(1, '2026-05-01', 4, 1001, 100, '2026-04-15'),
(2, '2026-05-03', 2, 1002, 101, '2026-04-16'),
(3, '2026-05-05', 6, 1003, 102, '2026-04-17'),
(4, '2026-05-10', 3, 1004, 103, '2026-04-18'),
(5, '2026-05-12', 5, 1005, 104, '2026-04-19');

SELECT * FROM `Order`;
