package common;

import java.io.Serializable;

/**
 * Represents a message exchanged between Client and Server.
 * Uses Command enum for type safety (no typos, compile-time checking).
 * Supports any Serializable object as data (Requirement 3).
 */
public class Message implements Serializable {
    private static final long serialVersionUID = 1L;

    private Command command;
    private Object data;

    public Message(Command command, Object data) {
        this.command = command;
        this.data = data;
    }

    public Command getCommand() { return command; }
    public void setCommand(Command command) { this.command = command; }
    public Object getData() { return data; }
    public void setData(Object data) { this.data = data; }

    @Override
    public String toString() {
        return "Message{command=" + command + ", data=" + data + "}";
    }
}
