package client;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * ClientUI - Main entry point for the Client application.
 * Loads the FXML screen and sets up the stage.
 */
public class ClientUI extends Application {

    private ClientController controller;

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ClientView.fxml"));
        Parent root = loader.load();
        controller = loader.getController();

        primaryStage.setTitle("GoNature Client - Group 11");
        primaryStage.setScene(new Scene(root, 650, 680));

        primaryStage.setOnCloseRequest(e -> {
            controller.shutdown();
            try { Thread.sleep(300); } catch (InterruptedException ex) { Thread.currentThread().interrupt(); }
            Platform.exit();
            System.exit(0);
        });

        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
