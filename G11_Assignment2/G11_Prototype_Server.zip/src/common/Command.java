package common;

/**
 * Enum representing all possible commands exchanged between Client and Server.
 * Using an enum instead of String constants prevents typos and enables compile-time checking.
 */
public enum Command {
    // Client → Server requests
    GET_ORDER,
    GET_ALL_ORDERS,
    UPDATE_ORDER,
    CLIENT_CONNECT,
    CLIENT_DISCONNECT,

    // Server → Client responses
    ORDER_FOUND,
    ORDER_NOT_FOUND,
    ALL_ORDERS,
    UPDATE_SUCCESS,
    UPDATE_FAIL,
    ERROR
}
