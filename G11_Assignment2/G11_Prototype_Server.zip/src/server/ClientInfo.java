package server;

import javafx.beans.property.SimpleStringProperty;

/**
 * Represents a connected client row in the server's client table.
 */
public class ClientInfo {
    private final SimpleStringProperty ip;
    private final SimpleStringProperty hostName;
    private final SimpleStringProperty status;

    public ClientInfo(String ip, String hostName, String status) {
        this.ip = new SimpleStringProperty(ip);
        this.hostName = new SimpleStringProperty(hostName);
        this.status = new SimpleStringProperty(status);
    }

    public String getIp() { return ip.get(); }
    public String getHostName() { return hostName.get(); }
    public String getStatus() { return status.get(); }
    public SimpleStringProperty ipProperty() { return ip; }
    public SimpleStringProperty hostNameProperty() { return hostName; }
    public SimpleStringProperty statusProperty() { return status; }
}
