package server;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * ServerUI - Main entry point for the Server application.
 * Loads the FXML screen and sets up the stage.
 */
public class ServerUI extends Application {

    private ServerController controller;

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ServerView.fxml"));
        Parent root = loader.load();
        controller = loader.getController();

        primaryStage.setTitle("GoNature Server - Group 11");
        primaryStage.setScene(new Scene(root, 550, 650));

        primaryStage.setOnCloseRequest(e -> {
            controller.shutdown();
            Platform.exit();
            System.exit(0);
        });

        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
