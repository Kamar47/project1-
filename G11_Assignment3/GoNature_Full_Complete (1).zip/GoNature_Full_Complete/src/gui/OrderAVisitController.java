package gui;

import client.*;
import common.*;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.*;
import javafx.scene.control.*;
import java.net.URL;
import java.util.*;

public class OrderAVisitController implements Initializable, ClientMessageHandler {
    @FXML private ComboBox<String> parkCombo, timeCombo, typeCombo;
    @FXML private DatePicker datePicker;
    @FXML private TextField visitorsField, emailField, phoneField;
    @FXML private Label priceLabel, statusLabel;
    private ArrayList<Park> parks;
    private String currentAction;
    private Order pendingOrder;
    private boolean isSubmitting = false;
    private String lastConfirmedOrderKey = null;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    	statusLabel.setWrapText(true);
        timeCombo.setItems(FXCollections.observableArrayList("08:00","09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00"));
        typeCombo.setItems(FXCollections.observableArrayList("individual","family","organized_group"));
        Traveler t = TravelerLoginController.getLoggedInTraveler();
        if (t != null) {
            if (t.getEmail() != null) emailField.setText(t.getEmail());
            if (t.getPhone() != null) phoneField.setText(t.getPhone());
        }
        visitorsField.textProperty().addListener((o, ov, nv) -> updatePrice());
        typeCombo.valueProperty().addListener((o, ov, nv) -> updatePrice());
        parkCombo.valueProperty().addListener((o, ov, nv) -> updatePrice());
        
        if (!ClientUI.isServerConnected()) {
            showError("Server is disconnected. Cannot load parks or create an order.");
            return;
        }

        currentAction = "LOAD_PARKS";
        ClientUI.client.setHandler(this);
        ClientUI.client.sendMessage(new ClientServerMessage(Command.GET_ALL_PARKS));
    }

    private void updatePrice() {
        if (parks == null || parkCombo.getValue() == null || typeCombo.getValue() == null || visitorsField.getText().isEmpty()) {
            priceLabel.setText("--"); return;
        }
        try {
            Park park = parks.stream().filter(p -> p.getParkName().equals(parkCombo.getValue())).findFirst().orElse(null);
            if (park == null) return;
            int visitors = Integer.parseInt(visitorsField.getText().trim());
            Traveler t = TravelerLoginController.getLoggedInTraveler();
            boolean isSub = t != null && t.getSubscriberId() > 0;
            double price = Pricing.calculatePrice(typeCombo.getValue(), visitors, park.getFullPrice(), isSub, false);
            priceLabel.setText(price + " NIS");
        } catch (NumberFormatException e) { priceLabel.setText("--"); }
    }

    @FXML
    private void handleSubmit() {
        System.out.println("[OrderVisit] Submit clicked");
        if (isSubmitting) {
            showError("Order is already being submitted. Please wait.");
            return;
        }

        StringBuilder errors = new StringBuilder();

        // Basic required fields
        if (parkCombo.getValue() == null) {
            errors.append("Park is required.\n");
        }

        if (datePicker.getValue() == null) {
            errors.append("Date is required.\n");
        } else if (datePicker.getValue().isBefore(java.time.LocalDate.now())) {
            errors.append("Date cannot be in the past.\n");
        }

        if (timeCombo.getValue() == null) {
            errors.append("Time is required.\n");
        }

        if (typeCombo.getValue() == null) {
            errors.append("Visit type is required.\n");
        }

        // Visitors validation
        int numVisitors = -1;

        if (visitorsField.getText().trim().isEmpty()) {
            errors.append("Number of visitors is required.\n");
        } else {
            try {
                numVisitors = Integer.parseInt(visitorsField.getText().trim());

                if (numVisitors <= 0) {
                    errors.append("Visitors must be positive.\n");
                }

                if (typeCombo.getValue() != null
                        && typeCombo.getValue().equals("organized_group")
                        && numVisitors > 15) {
                    errors.append("Organized group limited to 15 visitors.\n");
                }

            } catch (NumberFormatException e) {
                errors.append("Visitors must be a number.\n");
            }
        }

        // Email validation
        String emailError = InputValidation.validateEmail(emailField.getText());
        if (emailError != null) {
            errors.append(emailError).append("\n");
        }

        // Phone validation
        String phoneError = InputValidation.validatePhone(phoneField.getText());
        if (phoneError != null) {
            errors.append(phoneError).append("\n");
        }

        // Check if time already passed when booking for today
        if (datePicker.getValue() != null && timeCombo.getValue() != null) {
            if (datePicker.getValue().equals(java.time.LocalDate.now())) {
                java.time.LocalTime orderTime = java.time.LocalTime.parse(timeCombo.getValue());

                if (orderTime.isBefore(java.time.LocalTime.now())) {
                    errors.append("Cannot book for a time that already passed today. Please select a later time or a future date.\n");
                }
            }
        }

        // Only registered guides can book organized groups
        if (typeCombo.getValue() != null && typeCombo.getValue().equals("organized_group")) {
            Traveler traveler = TravelerLoginController.getLoggedInTraveler();

            if (traveler == null || !traveler.isGuide()) {
                errors.append("Only registered guides can book organized groups.\n");
            }
        }

        // If there are any validation errors, show all of them together
        if (errors.length() > 0) {
            showError(errors.toString().trim());
            return;
        }

        if (parks == null) {
            showError("Parks not loaded yet. Please wait.");
            return;
        }

        Traveler t = TravelerLoginController.getLoggedInTraveler();

        Park selectedPark = parks.stream()
                .filter(p -> p.getParkName().equals(parkCombo.getValue()))
                .findFirst()
                .orElse(null);

        if (selectedPark == null) {
            showError("Park not found.");
            return;
        }

        Order order = new Order();
        order.setVisitorId(t.getIdNumber());
        order.setParkId(selectedPark.getParkId());
        order.setParkName(selectedPark.getParkName());
        order.setVisitDate(datePicker.getValue().toString());
        order.setVisitTime(timeCombo.getValue() + ":00");
        order.setNumVisitors(numVisitors);
        order.setEmail(emailField.getText().trim());
        order.setPhone(phoneField.getText().trim());
        order.setOrderType(typeCombo.getValue());
        order.setSubscriberId(t.getSubscriberId());
        
        String currentOrderKey = buildOrderKey(order);

        if (currentOrderKey.equals(lastConfirmedOrderKey)) {
            showError("This order has already been confirmed. Please change the details before submitting again.");
            return;
        }

        pendingOrder = order;
        currentAction = "CREATE";
        isSubmitting = true;

        statusLabel.setText("Submitting order...");
        statusLabel.setStyle("-fx-text-fill: #f5a623;");

        System.out.println("[OrderVisit] Sending CREATE_ORDER: park=" + selectedPark.getParkId()
                + " date=" + order.getVisitDate() + " visitors=" + numVisitors);

        ClientUI.client.setHandler(this);
        ClientUI.client.sendMessage(new ClientServerMessage(Command.CREATE_ORDER, order));
    }

    private void showError(String msg) {
        statusLabel.setText(msg);
        statusLabel.setStyle("-fx-text-fill: #e94560;");
    }
    private String buildOrderKey(Order order) {
        if (order == null) {
            return "";
        }

        return order.getVisitorId() + "|"
                + order.getParkId() + "|"
                + order.getVisitDate() + "|"
                + order.getVisitTime() + "|"
                + order.getNumVisitors() + "|"
                + order.getEmail() + "|"
                + order.getPhone() + "|"
                + order.getOrderType();
    }

    @Override
    @SuppressWarnings("unchecked")
    public void handleMessage(ClientServerMessage msg) {
        System.out.println("[OrderVisit] Received: " + msg.getCommand() + " action=" + currentAction + " data=" + (msg.getData() != null ? msg.getData().getClass().getSimpleName() : "null"));

        Platform.runLater(() -> {
            try {
                switch (currentAction) {
                    case "LOAD_PARKS":
                        if (msg.getData() instanceof ArrayList) {
                            parks = (ArrayList<Park>) msg.getData();
                            ArrayList<String> names = new ArrayList<>();
                            for (Park p : parks) names.add(p.getParkName());
                            parkCombo.setItems(FXCollections.observableArrayList(names));
                            System.out.println("[OrderVisit] Loaded " + parks.size() + " parks");
                        }
                        break;

                    case "CREATE":
                        if (msg.getCommand() == Command.SUCCESS) {
                            if (msg.getData() instanceof Order) {
                                Order confirmed = (Order) msg.getData();
                                isSubmitting = false;
                                lastConfirmedOrderKey = buildOrderKey(confirmed);
                                statusLabel.setStyle("-fx-text-fill: #00e676;");
                                statusLabel.setText("Order confirmed! Code: " + confirmed.getConfirmationCode()
                                        + " | Price: " + confirmed.getTotalPrice() + " NIS");
                                NotificationSimulator.simulateBookingConfirmation(
                                    confirmed.getEmail(), confirmed.getPhone(), confirmed.getConfirmationCode(),
                                    pendingOrder.getParkName(), confirmed.getVisitDate(), confirmed.getVisitTime());
                            } else {
                                statusLabel.setStyle("-fx-text-fill: #00e676;");
                                statusLabel.setText("Order submitted successfully!");
                            }
                        } else if (msg.getCommand() == Command.FAILURE) {
                            String failMsg = msg.getData() != null ? msg.getData().toString() : "No availability";
                            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                            alert.setTitle("Park Full");
                            alert.setHeaderText("No availability at the requested time.");
                            alert.setContentText(failMsg + "\n\nWould you like to join the waiting list?");
                            ButtonType waitlistBtn = new ButtonType("Join Waiting List");
                            ButtonType cancelBtn = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
                            alert.getButtonTypes().setAll(waitlistBtn, cancelBtn);
                            Optional<ButtonType> result = alert.showAndWait();
                            if (result.isPresent() && result.get() == waitlistBtn) {
                                currentAction = "WAITLIST";
                                ClientUI.client.setHandler(this);
                                ClientUI.client.sendMessage(new ClientServerMessage(Command.ADD_TO_WAITLIST, pendingOrder));
                            } else {
                                showError("Booking cancelled.");
                            }
                        } else if (msg.getCommand() == Command.ERROR) {
                            showError("Server error: " + msg.getData());
                        } else {
                            showError("Unexpected response: " + msg.getCommand());
                        }
                        break;

                    case "WAITLIST":
                        if (msg.getCommand() == Command.SUCCESS) {
                            statusLabel.setStyle("-fx-text-fill: #f5a623;");
                            if (msg.getData() instanceof Order) {
                                Order wlOrder = (Order) msg.getData();
                                statusLabel.setText("Added to waiting list! Code: " + wlOrder.getConfirmationCode());
                            } else {
                                statusLabel.setText("Added to waiting list!");
                            }
                        } else {
                            showError("Failed to join waitlist: " + msg.getData());
                        }
                        break;

                    default:
                        System.out.println("[OrderVisit] Unhandled action: " + currentAction + " cmd: " + msg.getCommand());
                        break;
                }
            } catch (Exception e) {
                System.err.println("[OrderVisit] Error in handleMessage: " + e.getMessage());
                e.printStackTrace();
                showError("Error: " + e.getMessage());
            }
        });
    }

    @Override
    public void onDisconnected(String reason) { Platform.runLater(() -> showError(reason)); }
}