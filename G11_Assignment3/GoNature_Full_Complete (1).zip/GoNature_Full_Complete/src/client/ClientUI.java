package client;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ClientUI extends Application {
    public static GoNatureClient client;
    public static boolean isServerConnected() {
        return client != null && client.isConnected();
    }

    public static void markDisconnected() {
        client = null;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/HomePageFrame.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root, 800, 600);
        // Load CSS stylesheet
        try {
            String css = getClass().getResource("/styles/styles.css").toExternalForm();
            scene.getStylesheets().add(css);
        } catch (Exception e) { System.out.println("CSS not found, using defaults."); }

        primaryStage.setTitle("GoNature - Welcome");
        primaryStage.setScene(scene);
        primaryStage.setOnCloseRequest(e -> {
            if (client != null && client.isConnected()) {
                try { client.closeConnection(); } catch (Exception ex) {}
            }
            Platform.exit(); System.exit(0);
        });
        primaryStage.show();
    }

    public static void connectToServer(String host, int port) throws Exception {
        client = new GoNatureClient(host, port);
        client.openConnection();
    }

    public static void main(String[] args) { launch(args); }
}
