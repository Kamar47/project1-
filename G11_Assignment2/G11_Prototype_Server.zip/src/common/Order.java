package common;

import java.io.Serializable;

/**
 * Represents an Order entity from the database.
 * This class is shared between Client and Server.
 * Implements Serializable to allow transfer over network (Requirement 3).
 */
public class Order implements Serializable {
    private static final long serialVersionUID = 1L;

    private int orderNumber;
    private String orderDate;
    private int numberOfVisitors;
    private int confirmationCode;
    private int subscriberId;
    private String dateOfPlacingOrder;

    public Order(int orderNumber, String orderDate, int numberOfVisitors,
                 int confirmationCode, int subscriberId, String dateOfPlacingOrder) {
        this.orderNumber = orderNumber;
        this.orderDate = orderDate;
        this.numberOfVisitors = numberOfVisitors;
        this.confirmationCode = confirmationCode;
        this.subscriberId = subscriberId;
        this.dateOfPlacingOrder = dateOfPlacingOrder;
    }

    public int getOrderNumber() { return orderNumber; }
    public void setOrderNumber(int orderNumber) { this.orderNumber = orderNumber; }
    public String getOrderDate() { return orderDate; }
    public void setOrderDate(String orderDate) { this.orderDate = orderDate; }
    public int getNumberOfVisitors() { return numberOfVisitors; }
    public void setNumberOfVisitors(int numberOfVisitors) { this.numberOfVisitors = numberOfVisitors; }
    public int getConfirmationCode() { return confirmationCode; }
    public void setConfirmationCode(int confirmationCode) { this.confirmationCode = confirmationCode; }
    public int getSubscriberId() { return subscriberId; }
    public void setSubscriberId(int subscriberId) { this.subscriberId = subscriberId; }
    public String getDateOfPlacingOrder() { return dateOfPlacingOrder; }
    public void setDateOfPlacingOrder(String dateOfPlacingOrder) { this.dateOfPlacingOrder = dateOfPlacingOrder; }

    @Override
    public String toString() {
        return "Order #" + orderNumber + " | Date: " + orderDate +
               " | Visitors: " + numberOfVisitors + " | Code: " + confirmationCode +
               " | Subscriber: " + subscriberId + " | Placed: " + dateOfPlacingOrder;
    }
}
