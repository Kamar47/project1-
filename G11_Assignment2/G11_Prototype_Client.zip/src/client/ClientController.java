package client;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

import common.Command;
import common.Message;
import common.Order;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * ClientController - Handles all logic for the Client FXML screen.
 * Connected to ClientView.fxml via fx:controller.
 */
public class ClientController implements Initializable, ClientUIController {

    private GoNatureClient client;
    private ObservableList<Order> orderData;

    // === FXML Components (linked to ClientView.fxml) ===

    @FXML private TextField hostField;
    @FXML private TextField portField;
    @FXML private Button connectButton;
    @FXML private Button disconnectButton;

    @FXML private TextField orderNumberField;
    @FXML private Button getOrderButton;
    @FXML private Button getAllButton;

    @FXML private TableView<Order> orderTable;
    @FXML private TableColumn<Order, Integer> colOrderNum;
    @FXML private TableColumn<Order, String> colOrderDate;
    @FXML private TableColumn<Order, Integer> colVisitors;
    @FXML private TableColumn<Order, Integer> colConfCode;
    @FXML private TableColumn<Order, Integer> colSubId;
    @FXML private TableColumn<Order, String> colDatePlaced;

    @FXML private TextField updateOrderNumField;
    @FXML private TextField updateDateField;
    @FXML private TextField updateVisitorsField;
    @FXML private Button updateButton;

    @FXML private TextArea logArea;

    /**
     * Called automatically by JavaFX after FXML is loaded.
     * Sets up table columns and initial state.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Set up table columns
        colOrderNum.setCellValueFactory(new PropertyValueFactory<>("orderNumber"));
        colOrderDate.setCellValueFactory(new PropertyValueFactory<>("orderDate"));
        colVisitors.setCellValueFactory(new PropertyValueFactory<>("numberOfVisitors"));
        colConfCode.setCellValueFactory(new PropertyValueFactory<>("confirmationCode"));
        colSubId.setCellValueFactory(new PropertyValueFactory<>("subscriberId"));
        colDatePlaced.setCellValueFactory(new PropertyValueFactory<>("dateOfPlacingOrder"));

        orderData = FXCollections.observableArrayList();
        orderTable.setItems(orderData);

        // When user selects a row, populate update fields
        orderTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldVal, newVal) -> {
                    if (newVal != null) {
                        updateOrderNumField.setText(String.valueOf(newVal.getOrderNumber()));
                        updateDateField.setText(newVal.getOrderDate());
                        updateVisitorsField.setText(String.valueOf(newVal.getNumberOfVisitors()));
                    }
                }
        );

        setButtonsDisabled(true);
        appendLog("Client UI loaded. Enter server details and click 'Connect'.");
    }

    // ==================== FXML EVENT HANDLERS ====================

    @FXML
    private void handleConnect() {
        String host = hostField.getText().trim();
        String portStr = portField.getText().trim();

        if (host.isEmpty()) {
            appendLog("ERROR: Please enter a host address (e.g., localhost or 192.168.1.50).");
            return;
        }
        if (portStr.isEmpty()) {
            appendLog("ERROR: Please enter a port number.");
            return;
        }

        int port;
        try {
            port = Integer.parseInt(portStr);
        } catch (NumberFormatException e) {
            appendLog("ERROR: Port must be a number (e.g., 5555).");
            return;
        }
        if (port <= 0 || port > 65535) {
            appendLog("ERROR: Port must be between 1 and 65535.");
            return;
        }

        try {
            client = new GoNatureClient(host, port);
            client.setUiController(this);
            client.openConnection();

            connectButton.setDisable(true);
            disconnectButton.setDisable(false);
            hostField.setDisable(true);
            portField.setDisable(true);
            setButtonsDisabled(false);

        } catch (Exception e) {
            appendLog("ERROR: Could not connect to server at " + host + ":" + port + ". Make sure the server is running.");
        }
    }

    @FXML
    private void handleDisconnect() {
        if (client != null && client.isConnected()) {
            try {
                client.disconnectGracefully();
                appendLog("Disconnected from server.");
            } catch (Exception e) {
                appendLog("Error disconnecting: " + e.getMessage());
            }
        }
        client = null;
        resetUIAfterDisconnect();
    }

    @FXML
    private void handleGetOrder() {
        String numStr = orderNumberField.getText().trim();
        if (numStr.isEmpty()) {
            appendLog("ERROR: Please enter an order number.");
            return;
        }
        try {
            int orderNum = Integer.parseInt(numStr);
            if (orderNum <= 0) {
                appendLog("ERROR: Order number must be a positive number.");
                return;
            }
            client.sendRequest(new Message(Command.GET_ORDER, orderNum));
        } catch (NumberFormatException e) {
            appendLog("ERROR: Order number must be a whole number (e.g., 1, 2, 3).");
        }
    }

    @FXML
    private void handleGetAllOrders() {
        client.sendRequest(new Message(Command.GET_ALL_ORDERS, null));
    }

    @FXML
    private void handleUpdate() {
        String numStr = updateOrderNumField.getText().trim();
        String dateStr = updateDateField.getText().trim();
        String visitorsStr = updateVisitorsField.getText().trim();

        if (numStr.isEmpty() || orderTable.getSelectionModel().getSelectedItem() == null) {
            appendLog("ERROR: No order selected. Please click 'Get All Orders' and select an order from the table first.");
            return;
        }

        boolean hasError = false;
        int visitors = -1;

        // Validate date
        if (dateStr.isEmpty()) {
            appendLog("ERROR: Please enter a date (format: YYYY-MM-DD).");
            hasError = true;
        } else if (!dateStr.matches("\\d{4}-\\d{2}-\\d{2}")) {
            appendLog("ERROR: Invalid date format. Use YYYY-MM-DD (e.g., 2026-05-15).");
            hasError = true;
        } else {
            String[] dateParts = dateStr.split("-");
            try {
                int year = Integer.parseInt(dateParts[0]);
                int month = Integer.parseInt(dateParts[1]);
                int day = Integer.parseInt(dateParts[2]);
                boolean dateHasError = false;

                if (year < 2020 || year > 2099) {
                    appendLog("ERROR: Invalid year '" + year + "'. Year must be between 2020 and 2099.");
                    dateHasError = true; hasError = true;
                }
                boolean validMonth = true;
                if (month < 1 || month > 12) {
                    appendLog("ERROR: Invalid month '" + month + "'. Month must be between 1 and 12.");
                    validMonth = false; dateHasError = true; hasError = true;
                }
                if (validMonth) {
                    int[] daysInMonth = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
                    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) daysInMonth[2] = 29;
                    if (day < 1 || day > daysInMonth[month]) {
                        appendLog("ERROR: Invalid day '" + day + "' for month " + month + "/" + year
                                + ". Valid range: 1-" + daysInMonth[month] + ".");
                        dateHasError = true; hasError = true;
                    }
                } else if (day < 1 || day > 31) {
                    appendLog("ERROR: Invalid day '" + day + "'. Day must be between 1 and 31.");
                    dateHasError = true; hasError = true;
                }
                if (!dateHasError) {
                    LocalDate selectedDate = LocalDate.of(year, month, day);
                    if (selectedDate.isBefore(LocalDate.now())) {
                        appendLog("ERROR: Order date cannot be in the past.");
                        hasError = true;
                    }
                }
            } catch (NumberFormatException e) {
                appendLog("ERROR: Date must contain only numbers in format YYYY-MM-DD.");
                hasError = true;
            }
        }

        // Validate visitors
        if (visitorsStr.isEmpty()) {
            appendLog("ERROR: Please enter the number of visitors.");
            hasError = true;
        } else {
            try {
                visitors = Integer.parseInt(visitorsStr);
                if (visitors <= 0) {
                    appendLog("ERROR: Number of visitors must be a positive number (greater than 0).");
                    hasError = true;
                } else if (visitors > 15) {
                    appendLog("ERROR: Number of visitors must be less than or equal to 15.");
                    hasError = true;
                }
            } catch (NumberFormatException e) {
                appendLog("ERROR: Number of visitors must be a whole number (e.g., 3, 5, 10).");
                hasError = true;
            }
        }

        if (hasError) return;

        Order selectedOrder = orderTable.getSelectionModel().getSelectedItem();
        if (dateStr.equals(selectedOrder.getOrderDate()) && visitors == selectedOrder.getNumberOfVisitors()) {
            appendLog("ERROR: No changes were made. Please change the date or number of visitors before updating.");
            return;
        }

        try {
            int orderNum = Integer.parseInt(numStr);
            Order updateData = new Order(orderNum, dateStr, visitors, 0, 0, "");
            client.sendRequest(new Message(Command.UPDATE_ORDER, updateData));
        } catch (NumberFormatException e) {
            appendLog("ERROR: Invalid order number.");
        }
    }

    // ==================== HELPER METHODS ====================

    private void resetUIAfterDisconnect() {
        Platform.runLater(() -> {
            connectButton.setDisable(false);
            disconnectButton.setDisable(true);
            hostField.setDisable(false);
            portField.setDisable(false);
            orderData.clear();
            orderNumberField.clear();
            updateOrderNumField.clear();
            updateDateField.clear();
            updateVisitorsField.clear();
            setButtonsDisabled(true);
        });
    }

    private void setButtonsDisabled(boolean disabled) {
        getOrderButton.setDisable(disabled);
        getAllButton.setDisable(disabled);
        updateButton.setDisable(disabled);
        orderNumberField.setDisable(disabled);
        updateDateField.setDisable(disabled);
        updateVisitorsField.setDisable(disabled);
        orderTable.setDisable(disabled);
    }

    /**
     * Called when the window is closing. Disconnects gracefully.
     */
    public void shutdown() {
        handleDisconnect();
    }

    // ==================== ClientUIController ====================

    @Override
    public void appendLog(String message) {
        Platform.runLater(() -> logArea.appendText(message + "\n"));
    }

    @Override
    public void displayOrder(Object orderData) {
        Platform.runLater(() -> {
            this.orderData.clear();
            if (orderData instanceof Order) {
                this.orderData.add((Order) orderData);
                appendLog("Order loaded successfully.");
            }
        });
    }

    @Override
    @SuppressWarnings("unchecked")
    public void displayAllOrders(Object ordersData) {
        Platform.runLater(() -> {
            this.orderData.clear();
            if (ordersData instanceof List) {
                List<Order> orders = (List<Order>) ordersData;
                this.orderData.addAll(orders);
                appendLog(orders.size() + " orders loaded.");
            }
        });
    }

    @Override
    public void onUpdateSuccess(int orderNumber) {
        Platform.runLater(() -> appendLog("Order #" + orderNumber + " updated. Click 'Get All Orders' to see changes."));
    }

    @Override
    public void onServerDisconnected(String reason) {
        Platform.runLater(() -> {
            appendLog("DISCONNECTED: " + reason);
            resetUIAfterDisconnect();
        });
    }
}
